<?php include 'header.php';?>
<!-- //header -->
	<img src="images/elkSocialMedia.jpg"   width="100%" height="500" alt="BAnner" >
	 
	</div>
<hr>
	<div class="container">
		
		<hr>
	
	
	<div class="row panel panel-default sect">
				<div class="col-md-6">
					<img src="images/socialmedia1.jpg" class="img-responsive"  alt="social media Image">
				</div>
				<div class="col-md-5 col-md-push-1 ">
					<div class="section-heading">
						<h2 class="panel-heading">Social Media Prints</h2>
						<p>Do you have beautiful memorable pictures of friends and family get together, vacations and picnics Online that you would love to have photo print of ?
						EL-K has the latest digital and social media trend, which makes it easy for you if you would like to print photos of images from your face book page.
						</p>
						<br>
						 
					</div>
				</div>
				
	</div>
	<div class="panel row panel-default ">
			 
			 
					 <img src="images/smfriends.jpg" class="img-responsive" alt="social media" style="float:right;width:600px;height:420px;">
				
			 <div class="col-md-5 col-md-pull ">
					<div class="section-heading">
			<h2 class="panel-heading">Just Upload and We Print</h2>
			<p>					
				As we always love to serve you best with no stress on you, when you click to order, 
				there is an option for you to upload your photo for us to print it.
			</p>
					<br>
					<p><a href="#" class="btn btn-primary btn-outline">Click to Order</a></p>
					</div>
					</div>
	</div>
	
	</div>
		 

<!--footer-->
<?php include 'footer.php';?>