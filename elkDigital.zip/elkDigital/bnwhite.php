<?php include 'header.php';?>
<!-- //header -->
	 
	<img src="images/111.jpg"   style="width:100%; height:500px;" alt="BAnner" >
<div class="container">
    <hr>
	
	
	<div class="row panel panel-default sect">
				<div class="col-md-6">
					<img src="images/black.jpg" class="img-responsive"  alt="blacknWhite Image">
				</div>
				<div class="col-md-5 col-md-push-1 ">
					<div class="section-heading">
						<h2 class="panel-heading">Black and White Photos</h2>
						<p>Over the years black and white photos has been able to maintain a unique quality, its stands out in photography, bringing out a natural beauty in 
						every photograph,little wonder is in vogue again in the 21st century. Try taking a black and white photo at EL-K and you will simply love it!
						<br>
						Black and white film can be developed and printed at EL-K along with reprints and photo enlargements of what you will like, you just need to make your choice and we will deliver.
				it can also be produced from color images, giving your original color shots a natural beauty of black and white young look.
						</p>
						<br>
						<p><a href="bookNow.php" class="btn btn-primary btn-outline">Click to Order</a></p>
					</div>
				</div>
				
	</div>
	<div class="panel row">
	
			 
			<h2 class="panel-heading">Uniqueness in Black and White Photograph</h2>
					<p>
					<img src="images/40.jpg" alt="Black and White" class="img-responsive" style="float:right;width:550px;height:420px;">
						<img src="images/baby1.jpg" alt="Black and White" class="img-responsive" style="float:left;width:550px;height:420px;">
						</p>
			<!-- 	Black and white film can be developed and printed at El-k along with reprints and photo enlargements of what you will like, you just need to make your choice and we will deliver.
				it can also be produced from color images, giving your original color shots a natural beauty of black and white young look.
			  
					<br>
					<p><a href="#" class="btn btn-primary btn-outline">Click to Order</a></p> -->
	</div>
</div>
	
	 
	<!-- //footer -->
<?php include 'footer.php';?>