<?php include 'header.php';?>
<!-- //header -->
	<img src="images/andrew.jpg"   width="100%" height="500" alt="BAnner" >
<hr>
	<div class="container">
		
		<hr>
	
	
	<div class="row panel panel-default sect">
				<div class="col-md-6">
					<img src="images/photobook.jpg" class="img-responsive"  alt="photoBook">
				</div>
				<div class="col-md-5 col-md-push-1 ">
					<div class="section-heading">
						<h2 class="panel-heading">Personalised PhotoBook</h2>
						<p>Do it your own way and stand out of the crowd, choose your favorite
						photo as the cover photo and have other lovely pictures of friends and 
						family in your own photo book, You can also create a photo book for your wedding ceremonies, 
						birthday celebration, bridal shower, baby shower, baby’s early years, sports etc. just what you want!
						</p>
						<br>
						<!-- <p><a href="#" class="btn btn-primary btn-outline">Click to Order</a></p> -->
					</div>
				</div>
				
	</div>
	<div class="panel row">
	
			 
			<h2 class="panel-heading">Baby PhotoBook</h2>
					<p>
					<img src="images/photobook2.jpg" alt="photobook" class="img-responsive" style="float:right;width:600px;height:420px;">
				Do it your own way and stand out of the crowd, choose your favourite photo as the cover photo and have other lovely pictures
				of friends and family in your own photo book,
				You can also create a photo book for your wedding ceremonies, birthday celebration, bridal shower, baby shower,
				baby’s early years, sports etc. just what you want!
			  </p>
					<br>
					<p><a href="http://shop.elkdigitalsolutions.com.ng/22-personalised-photo-book" target="_blank" class="btn btn-primary btn-outline">Click to Order</a></p>
	</div>
	
	</div>
		 

<!--footer-->
 
	 
<?php include 'footer.php';?>