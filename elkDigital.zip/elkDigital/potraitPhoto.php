<?php include 'header.php';?>
<!-- //header -->
 <img src="images/ .jpg"   width="100%" height="500" alt="BAnner" >
<hr>
<br>
<div class="container">
			 
			
			<div class="row panel panel-default">
				<div class="col-md-6 col-md-pull  img-wrap animate-box" data-animate-effect="fadeInRight">
					<img src="images/potrait2.jpg"  class="img-responsive" alt=" ">
				</div>
				<div class="col-md-5 col-md-push-1 animate-box">
					<div class="section-heading">
						<h2>Professional Potrait Photo</h2>
						<p>We use skilled professional photographers, the most up to date cameras 
						and studio equipment to shoot head-shots for corporate websites, social media
						and business cards. We also shoot marketing materials such as product catalogs, advertising and PR campaigns.</p><br>

					<p>Our product photography is perfect for marketing, editorial as well as Online shops. As photo experts, 
						  our professional photo specialists can retouch all studio images where
						needed to ensure colors are bright, sharp and clear..</p>
						 
						 
					</div>
					<br>
					<p><a href="#" class="btn btn-primary btn-outline">Click to Order</a></p>
				</div>
			</div>
		<!--	<div class="panel row panel-default">					
					<img src="images/potrait1.jpg" alt="Calendar 2" style="float:right;width:500px;height:420px;">
					
				<div class="col-md-5 col-md-pull ">
				<h2 class="section-heading">Potrait Photo</h2>
					<p>
					Black and white film can be developed and printed at El-k along with reprints and photo enlargements of what you will like, you just need to make your choice and we will deliver.
					it can also be produced from colour images, giving your original colour shots a natural beauty of black and white young look.
					</p>
					<br>
					<p><a href="#" class="btn btn-primary btn-outline">Click to Order</a></p>
				</div>
			</div> -->
			 
</div>

 

 
	<!-- //footer -->
<?php include 'footer.php';?>