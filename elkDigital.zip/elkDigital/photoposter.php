<?php include 'header.php';?>
<!-- //header -->
	 
	<img src="images/photoprint.jpg"   style="width:100%; height:500px;" alt="BAnner" >
<div class="container">
    <hr>
	
	
	<div class="row panel panel-default sect">
				<div class="col-md-6">
					<img src="images/photoprint1.jpg" class="img-responsive"  alt="blacknWhite Image">
				</div>
				<div class="col-md-5 col-md-push-1 ">
					<div class="section-heading">
						<h2 class="panel-heading">Photo Poster Prints</h2>
						<p>Those beautiful pictures of yours, with loved ones and family are what you should really be proud of, display
						them by having us transform your wonderful experience into picture perfect wall art. We can print personalized 
						photo posters from an existing photo prints that you already have.
						</p>
						<br>
						 <p><a href="#" class="btn btn-primary btn-outline">Click to Order</a></p>
					</div>
				</div>
				
	</div>
	<!--<div class="panel row">
	
			 
			<h2 class="panel-heading">We are print specialist</h2>
			<img src="images/photoprint2.jpg" alt=" poster" class="img-responsive "  style="float:right;width:600px;height:420px;">
					<div class="col-md-5 col-md-pull">
					<p class="pull-left">
					Those beautiful pictures of yours, with loved ones and family are what you should really be proud of, display 
					them by having us transform your wonderful experience into picture perfect wall art. We can print personalized 
					photo posters from an existing photo prints that you already have.
					</p>
					<br>
					
					</div>
					
	</div> -->
</div>
	
	
 
	<!-- //footer -->
<?php include 'footer.php';?>