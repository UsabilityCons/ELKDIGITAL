<?php include 'header.php';?>
	<!-- //header -->
 <img src="images/elkEid.jpg"   width="100%" height="500" alt="BAnner" >
 <hr>


<div class="container">
			 
	<div class="row">
		<div class="col-lg-6 ">
				<div class="thumbnail">
				  <img src="images/sallah4her.jpg" class="img-responsive " alt="her">
				  <div class="caption">
					<h3>Gift for her</h3>
					<p>
					Show love to friends and family, personalise gift to share the love of the season.
					</p>
					<br>
					<p><a href="http://shop.elkdigitalsolutions.com.ng/17-photo-gifts" target="_blank" class="btn btn-primary" role="button">Book Now</a></p>
				  </div>
				</div>
        </div>
 
		  <div class="col-lg-6 ">
			<div class="thumbnail">
			  <img src="images/sallah4him.jpg" class="img-responsive" alt="him">
			  <div class="caption">
				<h3>Gift for him</h3>
				<p>
				Show love to friends and family, personalise gift to share the love of the season.
				</p>
				<br>
				<p><a href="#" class="btn btn-primary" role="button">Book Now</a></p>
			  </div>
			</div>
		  </div>
		  <div class="col-lg-6 ">
			<div class="thumbnail">
			  <img src="images/sallah4frame.jpg" class="img-responsive " alt="frames">
			  <div class="caption">
				<h3>Photo Prints & Frames</h3>
				<p>
				Show love to friends and family, personalise gift to share the love of the season.
				</p>
				<br>
				<p><a href="#" class="btn btn-primary" role="button">Book Now</a></p>
			  </div>
			</div>
		  </div>
		  <div class="col-lg-6 ">
			<div class="thumbnail">
			  <img src="images/sallah4kids.jpg" class="img-responsive " alt="kids">
			  <div class="caption">
				<h3>Gift For Kids</h3>
				<p>
				Show love to friends and family, personalise gift to share the love of the season.
				</p>
				<br>
				<p><a href="#" class="btn btn-primary" role="button">Book Now</a></p>
			  </div>
			</div>
		  </div>
	</div>
</div>

 
	<!-- //footer -->
<?php include 'footer.php';?>