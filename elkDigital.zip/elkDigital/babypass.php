<?php include 'header.php';?>
<!-- //header -->
 <img src="images/elkBaby.jpg"   width="100%" height="500" alt="BAnner" >
 
<div class="container">
			 
			 
<div class="container">
    <hr>
	
	
	 
	<div class="panel row">
	
			 
			<h2 class="panel-heading">Photos taken with care and patience</h2>
					<p>
					<img src="images/babypass1.jpg" alt="Baby Passport" class="img-responsive" style="float:right;width:550px;height:420px;">
					We understand that it is quite difficult trying to get children to take photograph and also the joy of saving wonderful memories 
					of that precious child, Because of this fact, we have professionals who are ready to take all the patience and care to get an excellent result.
					</p>
					 
	</div>
	<div class="panel row">
		 
			 
					<div>
					<img src="images/babypass2.jpg" alt="Baby" class="img-responsive" style="float:left;width:600px;height:420px;"> 
					</div>
					<div class="pht">
					<p>
					We understand that it is quite difficult trying to get children to take photograph and also the joy of 
					saving wonderful memories of that precious child, Because of this fact, we have professionals who are 
					ready to take all the patience and care to get an excellent result.
					</p>
					</div>
					<br>
					<p><a href="http://shop.elkdigitalsolutions.com.ng/24-international-passport-photos" target="_blank" class="btn btn-primary btn-outline pull-right">Click to Order</a></p>
					 
	</div>
</div>
			 
			 
			 
		</div>

 

 
	<!-- //footer -->
<?php include 'footer.php';?>