<?php include 'header.php';?>
<!-- //header -->
	<img src="images/g8.jpg"   width="100%" height="500" alt="BAnner"  >
	 
	 <div class="container">
    <hr>
	
	
	<div class="row panel panel-default sect">
				<div class="col-md-6">
					<img src="images/g7.jpg"  class="img-responsive" alt="photo PrintOnline">
				</div>
				<div class="col-md-5 col-md-push-1 ">
					<div class="section-heading">
						<h2 class="panel-heading">Photo Printing Online</h2>
						<p>At EL- K,we are up to serve you with high quality of service and less stress on you, that is why we made available this service to our esteemed customers.
						You will like to print photos Online from the comfort of your home and you are wondering if that kind of service will be available. Yes it is, At EL- K Digital Solutions. 
						</p>
						
						<p>All you need to do is to make an order, upload your picture and choose one of the preferred method of collection which is Pick Up 
						or Delivery.
						</p>
					    <br>
					<p><a href="#" class="btn btn-primary btn-outline">Click to Order</a></p> 
					</div>
				</div>
				
	</div>
	<div class="panel row">
	
			 
			<h2 class="panel-heading"></h2>
					<p>
					<img src="images/photoprint.jpg" alt="Photo Printonline" class="img-responsive" style="float:right;width:550px;height:420px;">
					<img src="images/photoprint1.jpg" alt="Photo printOnline" class="img-responsive" style="float:left;width:550px;height:420px;">
			  </p>
					
	</div>
</div>
	
	
	 
	<!-- //footer -->
<?php include 'footer.php';?>