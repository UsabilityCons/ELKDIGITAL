<?php include 'header.php';?>
<!-- //header -->
<!--start-gallery-->
<div class="gallery" id="gallery">
	 <div class="agileits_heading_section">
				<h3 class="wthree_head">Our Recent Work</h3>
				<p class="w3l_sub_para_agile">For Digital Life</p>
			</div>
			<div class="inner_w3l_agile_grids">
				<div class="col-md-3 gallery-grid gallery1">
					<a href="images/4.jpg" class="swipebox"><img src="images/05.jpg" class="img-responsive" alt="/">
						<div class="textbox">
						<h4>El-K Digital </h4>
							<p><i class="fa fa-eye" aria-hidden="true"></i></p>
							
						</div>
				</a>
				</div>
				<div class="col-md-3 gallery-grid gallery1">
					<a href="images/11.jpg" class="swipebox"><img src="images/01.jpg" class="img-responsive" alt="/">
						<div class="textbox">
						<h4>El-K Digital </h4>
							<p><i class="fa fa-eye" aria-hidden="true"></i></p>
						
						</div>
				</a>
				</div>
				<div class="col-md-3 gallery-grid gallery1">
					<a href="images/5.jpg" class="swipebox"><img src="images/03.jpg" class="img-responsive" alt="/">
						<div class="textbox">
						<h4>El-K Digital </h4>
							<p><i class="fa fa-eye" aria-hidden="true"></i></p>
							
						</div>
				</a>
				</div>
				<div class="col-md-3 gallery-grid gallery1">
					<a href="images/10.jpg" class="swipebox"><img src="images/04.jpg" class="img-responsive" alt="/">
						<div class="textbox">
						<h4>El-K Digital </h4>
							<p><i class="fa fa-eye" aria-hidden="true"></i></p>
							
						</div>
				</a>
				</div>
				<div class="col-md-3 gallery-grid gallery1">
					<a href="images/200.jpg" class="swipebox"><img src="images/03.jpg" class="img-responsive" alt="/">
						<div class="textbox">
						<h4>El-K Digital </h4>
							<p><i class="fa fa-eye" aria-hidden="true"></i></p>
							
						</div>
					</a>
				</div>
				<div class="col-md-3 gallery-grid gallery1">
					<a href="images/6.jpg" class="swipebox"><img src="images/23.jpg" class="img-responsive" alt="/">
						<div class="textbox">
						<h4>El-K Digital </h4>
							<p><i class="fa fa-eye" aria-hidden="true"></i></p>
					   </div>
				   </a>
				</div>
				<div class="col-md-3 gallery-grid gallery1">
					<a href="images/11.jpg" class="swipebox"><img src="images/11.jpg" class="img-responsive" alt="/">
						<div class="textbox">
						<h4>El-K Digital </h4>
							<p><i class="fa fa-eye" aria-hidden="true"></i></p>
					   </div>
				   </a>
				</div>
				<div class="col-md-3 gallery-grid gallery1">
					<a href="images/6.jpg" class="swipebox"><img src="images/02.jpg" class="img-responsive" alt="/">
						<div class="textbox">
						<h4>El-K Digital</h4>
							<p><i class="fa fa-eye" aria-hidden="true"></i></p>
					   </div>
				   </a>
				</div>
					<div class="col-md-3 gallery-grid gallery1">
					<a href="images/10.jpg" class="swipebox"><img src="images/10.jpg" class="img-responsive" alt="/">
						<div class="textbox">
						<h4>El-K Digital</h4>
							<p><i class="fa fa-eye" aria-hidden="true"></i></p>
							
						</div>
				</a>
				</div>
				<div class="col-md-3 gallery-grid gallery1">
					<a href="images/5.jpg" class="swipebox"><img src="images/5.jpg" class="img-responsive" alt="/">
						<div class="textbox">
						<h4>El-K Digital</h4>
							<p><i class="fa fa-eye" aria-hidden="true"></i></p>
						
						</div>
				</a>
				</div>
				<div class="col-md-3 gallery-grid gallery1">
					<a href="images/4.jpg" class="swipebox"><img src="images/4.jpg" class="img-responsive" alt="/">
						<div class="textbox">
						<h4>El-K Digital</h4>
							<p><i class="fa fa-eye" aria-hidden="true"></i></p>
							
						</div>
				</a>
				</div>
				<div class="col-md-3 gallery-grid gallery1">
					<a href="images/11.jpg" class="swipebox"><img src="images/06.jpg" class="img-responsive" alt="/">
						<div class="textbox">
						<h4>El-K Digital</h4>
							<p><i class="fa fa-eye" aria-hidden="true"></i></p>
							
						</div>
				</a>
				</div>
				<div class="col-md-3 gallery-grid gallery1">
					<a href="images/11.jpg" class="swipebox"><img src="images/06.jpg" class="img-responsive" alt="/">
						<div class="textbox">
						<h4>El-K Digital</h4>
							<p><i class="fa fa-eye" aria-hidden="true"></i></p>
							
						</div>
				</a>
				</div>
				<div class="col-md-3 gallery-grid gallery1">
					<a href="images/11.jpg" class="swipebox"><img src="images/06.jpg" class="img-responsive" alt="/">
						<div class="textbox">
						<h4>El-K Digital</h4>
							<p><i class="fa fa-eye" aria-hidden="true"></i></p>
							
						</div>
				</a>
				</div>
				<div class="col-md-3 gallery-grid gallery1">
					<a href="images/11.jpg" class="swipebox"><img src="images/06.jpg" class="img-responsive" alt="/">
						<div class="textbox">
						<h4>El-K Digital</h4>
							<p><i class="fa fa-eye" aria-hidden="true"></i></p>
							
						</div>
				</a>
				</div>
				<div class="col-md-3 gallery-grid gallery1">
					<a href="images/11.jpg" class="swipebox"><img src="images/06.jpg" class="img-responsive" alt="/">
						<div class="textbox">
						<h4>El-K Digital</h4>
							<p><i class="fa fa-eye" aria-hidden="true"></i></p>
							
						</div>
				</a>
				</div>
				<div class="col-md-3 gallery-grid gallery1">
					<a href="images/11.jpg" class="swipebox"><img src="images/06.jpg" class="img-responsive" alt="/">
						<div class="textbox">
						<h4>El-K Digital</h4>
							<p><i class="fa fa-eye" aria-hidden="true"></i></p>
							
						</div>
				</a>
				</div>
				<div class="col-md-3 gallery-grid gallery1">
					<a href="images/11.jpg" class="swipebox"><img src="images/02.jpg" class="img-responsive" alt="/">
						<div class="textbox">
						<h4>El-K Digital</h4>
							<p><i class="fa fa-eye" aria-hidden="true"></i></p>
							
						</div>
				</a>
				</div>
				<div class="col-md-3 gallery-grid gallery1">
					<a href="images/11.jpg" class="swipebox"><img src="images/01.jpg" class="img-responsive" alt="/">
						<div class="textbox">
						<h4>El-K Digital</h4>
							<p><i class="fa fa-eye" aria-hidden="true"></i></p>
							
						</div>
				</a>
				</div>
				<div class="col-md-3 gallery-grid gallery1">
					<a href="images/11.jpg" class="swipebox"><img src="images/111.jpg" class="img-responsive" alt="/">
						<div class="textbox">
						<h4>El-K Digital</h4>
							<p><i class="fa fa-eye" aria-hidden="true"></i></p>
							
						</div>
				</a>
				</div>
				<div class="clearfix"> </div>
			</div>
		</div>	
	</div>
		
	<!--//gallery-->
	<hr>
	
	 

<!--footer-->
<?php include 'footer.php';?>