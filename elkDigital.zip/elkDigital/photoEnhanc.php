<?php include 'header.php';?>
<!-- //header -->
 <img src="images/photoenhance.jpg"   width="100%" height="500" alt="BAnner" >
<hr>
<div class="container">
			 
			
			<div class="row panel panel-default">
				<div class="col-md-6 col-md-pull  img-wrap animate-box" data-animate-effect="fadeInRight">
					<img src="images/photoenhance1.jpg" class="img-responsive" alt=" ">
				</div>
				<div class="col-md-5 col-md-push-1 animate-box">
					<div class="section-heading">
						<h2>Photo Enhancement</h2>
						<p>Do you have old and cherished photos that are torn, stained or have unsightly marks? Or do you simply want to brighten a faded photo?
							We can restore, retouch and recolor your old picture to what you want.
						</p>
						 
					</div>
					<br>
					<p><a href="#" class="btn btn-primary btn-outline">Click to Order</a></p>
				</div>
			</div>
			<!--<div class="panel row panel-default">					
					<img src="images/photoenhance2.jpg" alt="Calendar 2" style="float:right;width:600px;height:420px;">
					
				<div class="col-md-5 col-md-pull ">
				<h2 class="section-heading">We are print specialist</h2>
					<p>
					Black and white film can be developed and printed at El-k along with reprints and photo enlargements of what you will like, you just need to make your choice and we will deliver.
					it can also be produced from colour images, giving your original colour shots a natural beauty of black and white young look.
					</p>
					
				</div>
			</div> -->
			 
</div>

 

 
	<!-- //footer -->
<?php include 'footer.php';?>