<?php include 'header.php';?>
<!-- //header -->
 <img src="images/wallartBanner.jpg"   width="100%" height="500" alt="BAnner" >
<hr>
<div class="container">
			 
			
			<div class="row panel panel-default">
				<div class="col-md-6 col-md-pull  img-wrap animate-box" data-animate-effect="fadeInRight">
					<img src="images/wallart.jpg" class="img-responsive " alt=" ">
				</div>
				<div class="col-md-5 col-md-push-1 animate-box">
					<div class="section-heading">
						<h2>Personalised Wallart</h2>
						<p>
						It will be really nice to have all your precious memorable pictures been displayed beautifully on your wall, to keep alive and live on with those wonderful 
						priceless memories.
						</p>
						 
					</div>
				</div>
			</div>
			<div class="panel row panel">
	
			 
			<h2 class="panel-heading">We are print specialist</h2>
					
					<img src="images/wallart.jpg" alt="wallart" class="img-responsive " style="float:right;width:600px;height:420px;">
					<div class="col-md-5 col-md-pull ">
					<p>
					 It will be so nice to have your own personalised wall art from you photo print,
					 imagine walking around your home seeing beautiful pictures of you on the wall,
					 that’s wonderful! We can produce a personal art for you as stretched canvas prints,
					 collages and posters in ultra-modern frames that will add more beauty to your home.
					</p>
					<br>
					<p><a href="http://shop.elkdigitalsolutions.com.ng/29-personalised-wall-art" target="_blank" class="btn btn-primary btn-outline">Click to Order</a></p>
					</div>
	</div>
			 
</div>

 


<!--footer-->
	
	<?php include 'footer.php';?>