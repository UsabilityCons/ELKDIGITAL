<?php include 'header.php';?>
<!-- //header -->

<div class="about inner_w3l_agile_grids" id="about">
	<div class="container">
		<div class="about-main">
			<div class="col-md-6 about-left_w3ls_img">
				
			</div>
			<div class="col-md-6 about-right_w3ls">
		  <div class="about-top_agile_its">
			<h2>About Us</h2>
			<h5>Professional in photography</h5>
			<p>EL Kasam Nigeria Limited trading as EL- K Digital Solution And Photo Lab was founded in July 16th 1992, and is coming up as a recognized brand in the
			Nigeria Photo Industry. EL Kasam has a reputation for quality of service and excellent consumer care, The initial branches were located in Lagos Sango-Otta, Kaduna,
			Abuja, Minna. <p>Our Aim is to provide the best services and to satisfy our customer in photography needs in modern digital photography needs, and to enable our customers to relieve
			and share favorite moments with their friends and family. At EL- K we recognize how precious our customers are, and we endeavor to treat each and every customer with respect,
			ensure quality photo and handle each other with care.
			</p>
			<span>We understand how important customer care is and how pictures are treasured, we therefore help to capture real moments like, baby's first smile, birthday celebration,
			holiday memories, and many other professional photos that we work on to enable us give our customers the best result.
			</span> 
			 
		
			

	  </div>
    
	   </div>
    </div>
</div>
	 
 
 	
</div>
	
	 
	<!-- //footer -->
<?php include 'footer.php';?>