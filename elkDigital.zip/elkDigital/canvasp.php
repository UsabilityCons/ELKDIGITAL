<?php include 'header.php';?>
<!-- //header -->
 <img src="images/canvB.png"   width="100%" height="500" alt="BAnner" >
<hr>
<div class="container">
			 
			
			<div class="row panel panel-default">
				<div class="col-md-6 col-md-pull  img-wrap animate-box" data-animate-effect="fadeInRight">
					<img src="images/canv1.jpg" class="img-responsive " alt=" ">
				</div>
				<div class="col-md-5 col-md-push-1 animate-box">
					<div class="section-heading">
						<h2>Canvas Printing</h2>
						<p>Create your own world in your home, have your lovely photos
						with precious memories displayed as stretched photo canvases. 
						EL-K has a perfect quality that will suit your taste for excellence, we are here to always serve you best.</p>
						<p> </p>
						 
					</div>
				</div>
			</div>
			<div class="panel row">
	
			 
			<h2 class="panel-heading">We are print specialist</h2>
					<img src="images/canv2.jpg" alt="Balck and White" class="img-responsive " style="float:right;width:600px;height:420px;">
					<div class="col-md-5 col-md-pull ">
					<p>
					Create your own world in your home, have your lovely photos with precious memories displayed as stretched photo canvases.
					EL-K has a perfect quality that will suit your taste for excellence, we are here to always serve you best.
					
					</p>
					<br>
					<p><a href="http://shop.elkdigitalsolutions.com.ng/28-canvas-printing" target="_blank" class="btn btn-primary btn-outline">Click to Order</a></p>
					</div>
	</div>
			 
</div>

 

 
	<!-- //footer -->
<?php include 'footer.php';?>