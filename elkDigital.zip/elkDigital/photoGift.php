<?php include 'header.php';?>
<!-- //header -->
 <img src="images/giftBanner.jpg" class="img-responsive"  width="100%" height="500" alt="BAnner" >
   
	<hr>


<div class="container">
			 
	<div class="row">
		<div class="col-lg-6 ">
				<div class="thumbnail">
				  <img src="images/clothing.jpg" class="img-responsive" alt="clothing">
				  <div class="caption">
					<h3>Clothing</h3>
					<p>
					A unique way of making a personal statement on any occasion is on a t-shirt,
					whether it is for a wedding anniversary celebration, Grandma or Grandpa’s birthday
					celebration any special celebration. There’s always an image that would create a 
					talking point and bring back wonderful fun filled memories.
					</p>
					<br>
					<br>
				<br>
				<br>
			
					<p><a href="#" class="btn btn-primary" role="button">Book Now</a></p>
				  </div>
				</div>
        </div>
 
		  <div class="col-lg-6 ">
			<div class="thumbnail">
			  <img src="images/custmugs1.jpg" class="img-responsive" alt="mugs">
			  <div class="caption">
				<h3>Mugs</h3>
				<p>
				Surprise your loved ones and create your own style of mugs with all your
				favorite photos and people, ready to bring out and impress them with when they come visiting.
				</p>
				<br>
				<p><a href="#" class="btn btn-primary" role="button">Book Now</a></p>
			  </div>
			</div>
		  </div>
		  <div class="col-lg-6 ">
			<div class="thumbnail">
			  <img src="images/phonecase.jpg" class="img-responsive" alt="dog">
			  <div class="caption">
				<h3>Phone Cases</h3>
				<p>
				Have your photos or loved ones photo at the back of your phone case.
				</p>
				<br>
				<br>
				<br>
				<br>
				<br>
				<br>
				<br>
				 
				<p><a href="#" class="btn btn-primary" role="button">Book Now</a></p>
			  </div>
			</div>
		  </div>
		  <div class="col-lg-6 ">
			<div class="thumbnail">
			  <img src="images/clock.jpg" class="img-responsive" alt="clock">
			  <div class="caption">
				<h3>Clocks</h3>
				<p>
				Personalised clocks are perfect in adding to the beauty and creativity of your home.
				Add your most memorable photo with family and friends on your clock.
				</p>
				<br>
				<p><a href="#" class="btn btn-primary" role="button">Book Now</a></p>
			  </div>
			</div>
		  </div>
		   <div class="col-lg-6 ">
			<div class="thumbnail">
			  <img src="images/bag.jpg" class="img-responsive" alt="bags">
			  <div class="caption">
				<h3>Bags</h3>
				<p>
				Have your bags designed the way you want it, with the photos and text you want. It can serve as a souvenir for an occasion. 
				</p>
				<br>
				<p><a href="#" class="btn btn-primary" role="button">Book Now</a></p>
			  </div>
			</div>
		  </div>
		  <div class="col-lg-6 ">
			<div class="thumbnail">
			  <img src="images/keyrings.jpg" class="img-responsive" alt="keyrings">
			  <div class="caption">
				<h3>Key Rings</h3>
				<p>
				This is a perfect way of having it your own way even over little things that are yours, you can have your favorite quote or pictures on your key rings. 
				</p>
				<br>
				<br>
				<br>
				<br>
				<p><a href="#" class="btn btn-primary" role="button">Book Now</a></p>
			  </div>
			</div>
		  </div>
	</div>
</div>

<!--footer-->

	
	<?php include 'footer.php';?>