
<!--footer-->
<div class="agile-footer jarallax">
<div class="agile_overlay1">
         
		<div class="container">
		      <div class="cam"><a href="https://www.instagram.com/elkdigitalsolutions3844/"><i class="fa fa-camera" aria-hidden="true"></i></a></div>

			<div class="w3_agileits_social_media">
					<ul>
						
						<li><a href="https://www.facebook.com/Elk-Digital-Solutions-386393305115111/" class="wthree_facebook"><i class="fa fa-facebook" aria-hidden="true"></i></a></li>
						<li><a href="#" class="wthree_twitter"><i class="fa fa-twitter" aria-hidden="true"></i></a></li>
						 
					</ul>
				</div>

			<div class="copy-right">
				<p>© 2017 El-K Lab. All rights reserved |Design by <a href="http://usabilitycons.com">Usability Consultants</a></p>
			<h2 style="color:#f00;">Contact Us</h2>
				<p>Phone: +234 (80) 245-1234 Email : <a href="mailto:info@elkphotolab.com" class="colored">info@elkphotolab.com</a><br>
				Abuja Address:  NO 25B, Yakubu Gowon Crescent, Asokoro District Abuja.<br>
				Minna Adress: NO 109, Top Medical Junction Beside Land Mark Bakery, Tunga Minna.
				</p>
				<a href="https://p3plcpnl0910.prod.phx3.secureserver.net:2096/" style="color:#f00;" >Mail</a>
			</div>
		</div>
	</div>
</div>
	<!-- //footer -->

<a href="#" id="toTop" style="display: block;"> <span id="toTopHover" style="opacity: 1;"> </span></a>

	<!-- js -->
<script src="js/jquery-2.1.4.min.js"></script> 
<script src="js/JiSlider.js"></script>
		<script>
			$(window).load(function () {
				$('#JiSlider').JiSlider({color: '#fff', start: 3, reverse: true}).addClass('ff')
			})
		</script>
		 
			<script src="js/jarallax.js"></script>
	<script src="js/SmoothScroll.min.js"></script>
	<script type="text/javascript">
		/* init Jarallax */
		$('.jarallax').jarallax({
			speed: 0.5,
			imgWidth: 1366,
			imgHeight: 768
		})
	</script>

<!-- start-smoth-scrolling -->
<script src="js/jqBootstrapValidation.js"></script>
<script src="js/booknow.js"></script>
<script src="js/contact_me.js"></script>
<!-- //for bootstrap working -->
<!-- stats -->
	<script src="js/jquery.waypoints.min.js"></script>
	<script src="js/jquery.countup.js"></script>
		<script>
			$('.counter').countUp();
		</script>
<!-- //stats -->
<!-- start-smooth-scrolling -->
<script type="text/javascript" src="js/move-top.js"></script>
<script type="text/javascript" src="js/easing.js"></script>
<script type="text/javascript">
	jQuery(document).ready(function($) {
		$(".scroll").click(function(event){		
			event.preventDefault();
			$('html,body').animate({scrollTop:$(this.hash).offset().top},1000);
		});
	});
</script>
<!-- start-smooth-scrolling -->
<link rel="stylesheet" href="css/swipebox.css">
				<script src="js/jquery.swipebox.min.js"></script> 
					<script type="text/javascript">
						jQuery(function($) {
							$(".swipebox").swipebox();
						});
					</script>

<!-- here stars scrolling icon -->
	<script type="text/javascript">
		$(document).ready(function() {
			/*
				var defaults = {
				containerID: 'toTop', // fading element id
				containerHoverID: 'toTopHover', // fading element hover id
				scrollSpeed: 1200,
				easingType: 'linear' 
				};
			*/
								
			$().UItoTop({ easingType: 'easeOutQuart' });
								
			});
	</script>
<!-- //here ends scrolling icon -->

<script type="text/javascript" src="js/bootstrap-3.1.1.min.js"></script>


</body>
</html>