<?php include 'header.php';?>
<!-- //header -->
 <img src="images/PassportPhotos.png"   width="100%" height="500" alt="BAnner" >
 
<div class="container">
			 
			 
<div class="container">
    <hr>
	
	
	 
	<div class="panel row">
	
			 
			<h3 class="panel-heading">Passport and Visa photos for any country while you wait</h3>
					<p>
					<img src="images/passport1.jpg" alt="passport" class="img-responsive"   style="float:right;width:550px;height:420px;">
					EL-K will give you the perfect passport photos for any country, we give you the best of passport photos that won’t be rejected 
					for having the wrong dimensions or background. Visit us today to get the best.
					</p>
					 
	</div>
	<div class="panel row">
		 
			 
					<div>
					<img src="images/passport2.jpg" alt="passport" class="img-responsive" style="float:left;width:600px;height:420px;"> 
					</div>
					<div class="pht">
					<p>
					EL-K will give you the perfect passport photos for any country, we give you the best of passport photos that won’t be rejected for 
					having the wrong dimensions or background. Visit us today to get the best.
					</p>
					</div>
					<br>
					<p><a href="http://shop.elkdigitalsolutions.com.ng/24-international-passport-photos" target="_blank"class="btn btn-primary btn-outline pull-right">Click to Order</a></p>
					 
	</div>
</div>
			 
			 
			 
		</div>

 

<!--footer-->
<?php include 'footer.php';?>