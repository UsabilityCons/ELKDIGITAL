<?php include 'header.php';?>
<!-- //header -->
	<!-- //header -->
 <img src="images/studioBanner.jpg" class="img-responsive"  width="100%" height="500" alt="BAnner" >
 <hr>


<div class="container">
			 
	<div class="row">
		<div class="col-lg-6 ">
				<div class="thumbnail">
				  <img src="images/mk.jpg" class="img-responsive" alt="make up">
				  <div class="caption">
					<h3>Make Up</h3>
					<p>
					A good make-up makes an exceptional picture,We've got you covered to give you a good makeover.
					</p>
 					  
					<p><a href="#" class="btn btn-primary" role="button">Book Now</a></p>
				  </div>
				</div>
        </div>
 
		  <div class="col-lg-6 ">
			<div class="thumbnail">
			  <img src="images/03.jpg" class="img-responsive" alt="Gele">
			  <div class="caption">
				<h3>Gele Tying</h3>
				<p>
				Look great in your traditional attire with a well tired Gele to bring out the African beauty in you. EL-K at your service!
				</p>
				<br>
				<p><a href="#" class="btn btn-primary" role="button">Book Now</a></p>
			  </div>
			</div>
		  </div>
		  <div class="col-lg-6 ">
			<div class="thumbnail">
			  <img src="images/facepaint.jpg" class="img-responsive" alt="Face Painting">
			  <div class="caption">
				<h3>Face Painting</h3>
				<p>
				Face painting makes a loud statement in photography. We are at your service for a good face painting.
				</p>
				<br>
				<p><a href="#" class="btn btn-primary" role="button">Book Now</a></p>
			  </div>
			</div>
		  </div>
		  <div class="col-lg-6 ">
			<div class="thumbnail">
			  <img src="images/05.jpg" class="img-responsive" alt="Touch">
			  <div class="caption">
				<h3>Touchings</h3>
				<p>
				Want to give a touch to your make-up,our make-up artist are available to do that for you.
				</p>
				<br>
				<p><a href="#" class="btn btn-primary" role="button">Book Now</a></p>
			  </div>
			</div>
		  </div>
	</div>
</div>


<!--footer-->
	
<?php include 'footer.php';?>