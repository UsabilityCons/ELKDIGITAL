<?php include 'header.php';?>
	<!-- //header -->
 <img src="images/elkMugs.jpg"   width="100%" height="500" alt="BAnner" >
 <hr>


<div class="container">
			 
	<div class="row">
		<div class="col-lg-6 ">
				<div class="thumbnail">
				  <img src="images/elkMug1.jpg" class="img-responsive"  alt="mugs">
				  <div class="caption">
					<h3>Gift for her</h3>
					<p>
					Personalize Photo Mugs for her is a way of having your moment live close to you than ever,
					every time she uses the mug, she remembers that precious, priceless moment you had together that is to be cherished for life. 
					</p>
					<br>
					<p><a href="#" class="btn btn-primary" role="button">Book Now</a></p>
				  </div>
				</div>
        </div>
 
		  <div class="col-lg-6 ">
			<div class="thumbnail">
			  <img src="images/elkMug2.jpg" class="img-responsive"  alt="Mugs">
			  <div class="caption">
				<h3>Gift for him</h3>
				<p>
				Personalize Photo Mugs for him is a way of having your moment live close to you than ever, 
				every time he uses the mug, He remembers that precious, priceless moment you had together that is to be cherished for life. 
				</p>
				<br>
				<p><a href="#" class="btn btn-primary" role="button">Book Now</a></p>
			  </div>
			</div>
		  </div>
		  <div class="col-lg-6 ">
			<div class="thumbnail">
			  <img src="images/elkMug2.jpg" class="img-responsive"  alt="Mugs">
			  <div class="caption">
				<h3>Photo Prints & Mugs</h3>
				<p>
				Personalize Photo Mugs is a way of having your treasured moment live with you.   
				</p>
				<br>
				<p><a href="#" class="btn btn-primary" role="button">Book Now</a></p>
			  </div>
			</div>
		  </div>
		  <div class="col-lg-6 ">
			<div class="thumbnail">
			  <img src="images/elkMug1.jpg" class="img-responsive"  alt="Mugs">
			  <div class="caption">
				<h3>Gift For Kids</h3>
				<p>
				Personalize Photo Mugs for kids with their wonderful moments with friends, every time they take a hot tea, they remember the lovely times shared with 
				friends and family. 
				</p>
				<br>
				<p><a href="#" class="btn btn-primary" role="button">Book Now</a></p>
			  </div>
			</div>
		  </div>
	</div>
</div>

 
	<!-- //footer -->
<?php include 'footer.php';?>