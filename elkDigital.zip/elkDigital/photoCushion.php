<?php include 'header.php';?>
<!-- //header -->
	 
	<img src="images/cushionBanner.jpg"  class="img-responsive"  style="width:100%; height:500px;" alt="BAnner" >
<div class="container">
    <hr>
	
	
	<div class="row panel panel-default sect">
				<div class="col-md-6">
					<img src="images/cushion5.jpg"  class="img-responsive"  alt="cushion Image">
				</div>
				<div class="col-md-5 col-md-push-1 ">
					<div class="section-heading">
						<h2 class="panel-heading">Photo Cushion</h2>
						<p>Make the most of your priceless memories, have nice write-ups written by you on your cushion or
your family or personal pictures on your cushion to make your home more colorful with beautiful
memories.
						</p>
						<br>
						<!-- <p><a href="#" class="btn btn-primary btn-outline">Click to Order</a></p> -->
					</div>
				</div>
				
	</div>
	<div class="panel row">
	
				<img src="images/cushion4.jpg" alt="cushion"  class="img-responsive" style="float:right;width:600px;height:420px;">
				<div class="col-md-5 col-md-pull ">
				<h2 class="section-heading">Live In Lovely Memories</h2>
					<p>
					Cushions are simple ways to upgrade your home and add a spark of colour and unique style. 
					You can just use a personalised cushion to liven up your sitting room or bedroom. 
					</p>
					<br>
					<p><a href="#" class="btn btn-primary btn-outline">Click to Order</a></p>
				</div>
	</div>
</div>
	
	 
	<!-- //footer -->
<?php include 'footer.php';?>