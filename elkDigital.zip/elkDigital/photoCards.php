<?php include 'header.php';?>
<!-- //header -->
 <img src="images/elkCards.jpg"  class="img-responsive"  width="100%" height="500" alt="BAnner" >
   
	<hr>		 
			 
<div class="container">
    
	
	
	 
		<div class="panel row">
	
			 
			<h2 class="panel-heading">Personalised Photo Cards</h2>
					<p>
					<img src="images/cardgift1.jpg" alt=" Cards"  class="img-responsive" style="float:right;width:550px;height:420px;">
					A personalised card displaying a shared memory speaks a lot to a loved one. We personalise greeting cards for seasonal events like,
					Birthday cards, Christmas, Wedding Invitation, Easter, Sallah, Mother’s Day and Father’s Day all personalised with your own text and images.
					</p>
					 
		</div>
		<div class="row panel panel-default sect">
				<div class="col-md-6">
					<img src="images/cardgift2.jpg"   class="img-responsive" alt="Image">
				</div>
				<div class="col-md-5 col-md-push-1 ">
					<div class="section-heading">
						<h2 class="panel-heading">Photos</h2>
						<p>A personalised card displaying a shared memory speaks a lot to a loved one. We personalise greeting cards for seasonal events like,
						Birthday cards, Christmas, Wedding Invitation, Easter, Sallah, Mother’s Day and Father’s Day all personalised with your own text and images.!
						</p>
						<br>
						 <a href="#" class="btn btn-primary btn-outline">Click to Order</a> 
					</div>
				</div>
				
	</div>
		 
</div>
			 
			 
			 
		 

 


 
	<!-- //footer -->
<?php include 'footer.php';?>