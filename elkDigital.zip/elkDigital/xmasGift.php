<?php include 'header.php';?>
	<!-- //header -->
 <img src="images/elkXmas.jpg"   width="100%" height="500" alt="BAnner" >
 <hr>


<div class="container">
			 
	<div class="row">
		<div class="col-lg-6 ">
				<div class="thumbnail">
				  <img src="images/xmas4her.jpg" class="img-responsive" alt="xmas">
				  <div class="caption">
					<h3>Gift for her</h3>
					<p>
					Make her feel special and loved in the Christmas season,
					personalise a nice gift to say merry Christmas to her!!.
					</p>
					<br>
					<p><a href="http://shop.elkdigitalsolutions.com.ng/17-photo-gifts" target="_blank" class="btn btn-primary" role="button">Book Now</a></p>
				  </div>
				</div>
        </div>
 
		  <div class="col-lg-6 ">
			<div class="thumbnail">
			  <img src="images/xmas2.jpg" class="img-responsive" alt="xmas Gift for him">
			  <div class="caption">
				<h3>Gift for him</h3>
				<p>
				Make him feel special and loved in this Christmas season,
					personalise a nice gift to say merry Christmas to him!.
				</p>
				<br>
				<p><a href="http://shop.elkdigitalsolutions.com.ng/17-photo-gifts" target="_blank" class="btn btn-primary" role="button">Book Now</a></p>
			  </div>
			</div>
		  </div>
		  <div class="col-lg-6 ">
			<div class="thumbnail">
			  <img src="images/elk4.jpg" class="img-responsive" alt="Frames">
			  <div class="caption">
				<h3>Photo Prints&Frames</h3>
				<p>
				Make someone feel special and loved in the Christmas season,
					personalise a nice gift to say merry Christmas to your loved ones.
				</p>
				<br>
				<p><a href="http://shop.elkdigitalsolutions.com.ng/17-photo-gifts" target="_blank" class="btn btn-primary" role="button">Book Now</a></p>
			  </div>
			</div>
		  </div>
		  <div class="col-lg-6 ">
			<div class="thumbnail">
			  <img src="images/xmas4her.jpg" class="img-responsive" alt="Kids">
			  <div class="caption">
				<h3>Gift For Kids</h3>
				<p>
				Make kids feel special and loved in this Christmas season,
					personalise a nice gift to say merry Christmas to them!!.
				</p>
				<br>
				<p><a href="http://shop.elkdigitalsolutions.com.ng/17-photo-gifts" target="_blank" class="btn btn-primary" role="button">Book Now</a></p>
			  </div>
			</div>
		  </div>
	</div>
</div>


 
	<!-- //footer -->
<?php include 'footer.php';?>