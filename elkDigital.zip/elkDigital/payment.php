<link rel="stylesheet" href="css/elk.css" type="text/css">
		
<legend><center><h2>Order Basket</h2></center></legend>
 
<p id="cnames"><b>Full Name:</b></p>
<p><b>Email: </b><span id="cemail"></span></p>
<p><b>Phone Number: </b><span id="cphone"></span></p>
<p><b>Contact Address: </b><span id="caddress"></span></p>
<p><b>Service Description: </b><span id="cservice"></span></p>
<p><b>Delivery Type: </b><span id="cdelivery"></span></p>
<p><b>Quantity: </b><span id="cqnty"></span></p>
<p><b>Order No: </b><span id="orderNo"></span></p>
<p><b>No Of Items: </b><span id="totalItems"></span></p>
<p><b>Total Price: </b><span id="price"></span></p>
<!-- --<button class="btn-warning" >Place Order</button><!-- -->